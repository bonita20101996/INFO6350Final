//
//  ViewController.swift
//  final_test3
//
//  Created by yaoxiao on 12/09/2023.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, SendNamePhoneNumberDelegate {
   
    var names: [String] = [String]()
    var lastNames: [String] = [String]()
    var phoneNumbers: [String] = [String]()

    @IBOutlet weak var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func addNamePhoneNumber(_ sender: Any) {
        performSegue(withIdentifier: "segueNamePhoneNumber", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segueNamePhoneNumber" {
            let secondVC = segue.destination as! NamePhoneNumberViewController
            secondVC.sendNamePhoneDelegate = self
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = "First:\(names[indexPath.row]) Last:\(lastNames[indexPath.row]) Phone:\(phoneNumbers[indexPath.row])"
        return cell
    }
    
    func sendNamePhoneNumber(name: String, lastName: String, phoneNumber: String) {
        names.append(name)
        lastNames.append(lastName)
        phoneNumbers.append(phoneNumber)
        tblView.reloadData()
    }
}

