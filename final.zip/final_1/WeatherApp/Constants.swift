//
//  Constants.swift
//  StockAPIExample
//
//  Created by Drillmaps on 02/12/23.
//

import Foundation

let baseURL = "https://financialmodelingprep.com/api/v3/quote-short/"
let apiKey = "https://us-central1-fir-api-s-8d31b.cloudfunctions.net/app"
