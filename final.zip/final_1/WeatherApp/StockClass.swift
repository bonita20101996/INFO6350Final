//
//  StockClass.swift
//  StockAPIExample
//
//  Created by Drillmaps on 02/12/23.
//

import Foundation

class StockClass {
    var city: String = ""
    var temperature: Float = 0.0
    var condition: String = ""
}
